from __future__ import annotations

import logging
from os import environ
from typing import TYPE_CHECKING

from ... import Command
from ...batoceraPaths import BIOS, CONFIGS, SAVES, CACHE, mkdir_if_not_exists, ensure_parents_and_open
from ...utils import vulkan
from ...utils.configparser import CaseSensitiveRawConfigParser
from ..Generator import Generator

if TYPE_CHECKING:
    from pathlib import Path
    from ...Emulator import Emulator
    from ...controller import Controllers

_logger = logging.getLogger(__name__)

EDEN_CONFIG = CONFIGS / "eden"
SWITCH_BIOS = BIOS / "switch"


class EdenGenerator(Generator):

    def getHotkeysContext(self):
        return {
            "name": "eden",
            "keys": {"exit": ["KEY_LEFTALT", "KEY_F4"]}
        }

    def generate(self, system, rom, playersControllers, metadata, guns, wheels, gameResolution):

        # ---- filesystem layout ----
        mkdir_if_not_exists(SWITCH_BIOS)
        mkdir_if_not_exists(SWITCH_BIOS / "keys")
        mkdir_if_not_exists(SWITCH_BIOS / "firmware")

        mkdir_if_not_exists(EDEN_CONFIG)
        mkdir_if_not_exists(EDEN_CONFIG / "nand")
        mkdir_if_not_exists(EDEN_CONFIG / "nand" / "system")
        mkdir_if_not_exists(EDEN_CONFIG / "nand" / "user")
        mkdir_if_not_exists(EDEN_CONFIG / "load")

        mkdir_if_not_exists(SAVES / "switch" / "eden")

        EdenGenerator.writeConfig(
            EDEN_CONFIG / "qt-config.ini",
            system
        )

        return Command.Command(
            array=["/usr/bin/eden.AppImage", "-f", "-g", rom],
            env={
                "XDG_CONFIG_HOME": CONFIGS,
                "XDG_DATA_HOME": SAVES / "switch" / "eden",
                "XDG_CACHE_HOME": CACHE,
            }
        )

    @staticmethod
    def writeConfig(cfg: Path, system: Emulator):

        c = CaseSensitiveRawConfigParser()
        if cfg.exists():
            c.read(cfg)

        # ---------- UI ----------
        if not c.has_section("UI"):
            c.add_section("UI")

        c.set("UI", "fullscreen", "true")
        c.set("UI", "singleWindowMode", system.config.get("citron_single_window", "true"))
        c.set("UI", "enable_discord_presence", "false")
        c.set("UI", "confirmClose", "false")
        c.set("UI", "UIGameList\\cache_game_list", "false")

        c.set("UI", "Paths\\gamedirs\\1\\path", "/userdata/roms/switch")
        c.set("UI", "Paths\\gamedirs\\size", "1")

        # ---------- Data Storage ----------
        if not c.has_section("Data%20Storage"):
            c.add_section("Data%20Storage")

        c.set("Data%20Storage", "nand_directory", str(EDEN_CONFIG / "nand"))
        c.set("Data%20Storage", "load_directory", str(EDEN_CONFIG / "load"))
        c.set("Data%20Storage", "use_virtual_sd", "true")

        # ---------- Core ----------
        if not c.has_section("Core"):
            c.add_section("Core")

        c.set("Core", "use_multi_core", "true")

        # ---------- Renderer ----------
        if not c.has_section("Renderer"):
            c.add_section("Renderer")

        backend = system.config.get("citron_backend", "1")
        c.set("Renderer", "backend", backend)

        if backend == "1" and vulkan.is_available():
            if vulkan.has_discrete_gpu():
                idx = vulkan.get_discrete_gpu_index()
                if idx is not None:
                    c.set("Renderer", "vulkan_device", str(idx))

        c.set("Renderer", "use_asynchronous_gpu_emulation",
              system.config.get("citron_async_gpu", "true"))
        c.set("Renderer", "use_asynchronous_shaders",
              system.config.get("citron_async_shaders", "true"))
        c.set("Renderer", "nvdec_emulation",
              system.config.get("citron_nvdec_emu", "2"))
        c.set("Renderer", "gpu_accuracy",
              system.config.get("citron_accuracy", "0"))
        c.set("Renderer", "resolution_setup",
              system.config.get("citron_scale", "2"))
        c.set("Renderer", "accelerate_astc",
              system.config.get("citron_astc", "1"))

        # ---------- CPU ----------
        if not c.has_section("Cpu"):
            c.add_section("Cpu")

        c.set("Cpu", "cpu_accuracy",
              system.config.get("citron_cpuaccuracy", "0"))

        # ---------- System ----------
        if not c.has_section("System"):
            c.add_section("System")

        c.set("System", "language_index",
              system.config.get("citron_language", "1"))
        c.set("System", "region_index",
              system.config.get("citron_region", "2"))
        c.set("System", "use_docked_mode",
              system.config.get("citron_dock_mode", "true"))

        # ---------- Telemetry ----------
        if not c.has_section("WebService"):
            c.add_section("WebService")

        c.set("WebService", "enable_telemetry", "false")

        with ensure_parents_and_open(cfg, "w") as f:
            c.write(f)
